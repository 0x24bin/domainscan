--
-- 表的结构 `templates`
--

CREATE TABLE IF NOT EXISTS `doublecomcn` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `domainname` varchar(255) NOT NULL,
  `regstatus` varchar(200) NOT NULL,
  `regtime` datetime NOT NULL,
  `exptime` datetime NOT NULL,
  `regmonger` varchar(255) NOT NULL,
  `register` varchar(255) NOT NULL,
  `contact` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `domainstatus` varchar(255) NOT NULL,
  `dnsserver` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- 转存表中的数据 `doublecn`
--

